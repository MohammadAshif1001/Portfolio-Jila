<?php
header("Location: https://labs.cashjila.com");
exit; // Ensure script execution stops after redirection
?>