<?php
header("Location: https://labs.cashjila.com/error-page/404");
exit; // Ensure script execution stops after redirection
?>