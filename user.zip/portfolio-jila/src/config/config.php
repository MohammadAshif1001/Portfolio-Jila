<?php
$dbhost = "localhost:3306";
$dbuser = "a1645lsw_portfolio";
$dbpass = "op,,!EOh]gO7";
$dbname = "a1645lsw_portfolioJila";


$conn = mysqli_connect($dbhost , $dbuser , $dbpass , $dbname);
$localhost = "http://localhost/Project2024/Portfolio-Jila/";
if(!isset($conn)){
    echo die("Database connection failed");
}

$hostname = "https://labs.cashjila.com/";
?>